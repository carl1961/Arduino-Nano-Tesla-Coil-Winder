Overview:

Gcoil - Generates a Gcode routine which enables a CNC milling machine to be used as a coil winder.

Gflat � Creates a milling pattern to flat the bed of the milling machine.

Gopt � Optimises both drilling and milling paths.

Gpath � Removes close parallel paths between smd pads. 

Gskew � Compensates for skew or un-squareness in the milling machine.

Gtime � Calculates the time it takes to finish the milling job.



Changelog:

V1.0 
-First public release.

V1.1 
-Source and programs combined in one file.
-Gskew updated.

V1.2 
-Gflat added.
-Gopt added.

V1.3 
-Gcoil added.

V1.4 
-Gcoil updated.
-Some minor changes to some manuals.